import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api',
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use((config) => {
  const token = sessionStorage.getItem('paystride_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      sessionStorage.removeItem('paystride_token')
      sessionStorage.removeItem('paystride_user')
      localStorage.removeItem('paystride_token')
      localStorage.removeItem('paystride_user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
